const chalk = require('chalk')
const fs = require('fs')

global.menunya = (pushname, prefix, hituet) =>{
	return `╭─❒ 「 ORDER MENU 」
│
│○ .listproduk
│○ .order <code> <jumlah>
│○ .infoakun (untuk cek saldo)
│
╰❒ 

╭─❒ 「  GROUP MENU  」
│○ .list  
│○ .addlist  
│○ .updatelist  
│○ .dellist     
│○ .proses  
│○ .done  
│○ .setwelcome  
│○ .changewelcome  
│○ .delsetwelcome    
│○ .antiwame  [on/off]
│○ .antiwame2  [on/off]
│○ .antilink  [on/off]
│○ .antilink2  [on/off]
│○ .welcome  [on/off]
│○ .goodbye  [on/off]
│○ .group open
│○ .group close
│○ .hidetag  
│○ .kick  
│○ .linkgc  
│○ .resetlinkgc      
│○ .antilinkall  
│○ .mute [on/off]
│○ .afk
╰❒

╭─❒ 「 OWNER MENU 
│NB : Via Reply 
│
│○ .tambahsaldo (nominal)
│○ .kurangsaldo (nominal
│○ .tambahproduk (code)
│
╰❒

╭─❒ 「 INFO MENU 」 
│
│○ .cekidff
│○ .cekidml
│○ .owner
│
╰❒

NB : Command wajib menggunakan prefix . | # | !
`
}

/*
JANGAN HAPUS THANKS TO DEKS :V
KALO MAU NARUH NAMA LU TARUH AJA
*/

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})