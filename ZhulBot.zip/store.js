// NOTE BAGI YANG BELI SC INI \\

// JIKA MEMAKAI PANEL DI ENC DLU \\
// BUKAN PANEL AJA KALO MAU TARO SCRIPT NYA DI GITHUB JUGA USAHAKAN ENC \\
// KALO KAGAK DI ENC SC LU KELIATAN SAMA OWNER PANEL \\
// TUTORIAL ENC https://youtu.be/f5b2MJj9TPM

require("./settings");
require("./menunya");
const {
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType,
} = require("@adiwajshing/baileys");
const {
  baileys,
  cheerio,
  child_process,
  cookie,
  FileType,
  ffmpeg,
  Jimp,
  jsobfus,
  PhoneNumber,
  process,
  speed,
  syntaxerror,
  ytdl,
} = module;
const fs = require("fs");
const os = require("os");
const util = require("util");
const chalk = require("chalk");
const axios = require("axios");
const moment = require("moment-timezone");
const ms = (toMs = require("ms"));

//function DAPA
const {
  daftarAkun,
  userInfo,
  produkList,
  tambahSaldo,
  kurangSaldo,
  tambahStock,
  kurangStock,
  beliBarang
} = require('./lib/export')

// AFK \\
let _afk = JSON.parse(fs.readFileSync("./database/afk.json"));
const afk = require("./lib/afk");

// CONST STALKER \\
const { stalkff } = require("./RANDOM/STALKER/stalk-ff");
const { stalkml } = require("./RANDOM/STALKER/stalk-ml");

const { smsg, fetchJson, getBuffer } = require("./lib/simple");
const {
  updateResponList,
  delResponList,
  isAlreadyResponListGroup,
  sendResponList,
  isAlreadyResponList,
  getDataResponList,
  addResponList,
  isSetClose,
  addSetClose,
  removeSetClose,
  changeSetClose,
  getTextSetClose,
  isSetDone,
  addSetDone,
  removeSetDone,
  changeSetDone,
  getTextSetDone,
  isSetLeft,
  addSetLeft,
  removeSetLeft,
  changeSetLeft,
  getTextSetLeft,
  isSetOpen,
  addSetOpen,
  removeSetOpen,
  changeSetOpen,
  getTextSetOpen,
  isSetProses,
  addSetProses,
  removeSetProses,
  changeSetProses,
  getTextSetProses,
  isSetWelcome,
  addSetWelcome,
  removeSetWelcome,
  changeSetWelcome,
  getTextSetWelcome,
  addSewaGroup,
  getSewaExpired,
  getSewaPosition,
  expiredCheck,
  checkSewaGroup,
  addPay,
  updatePay,
} = require("./lib/store");

async function getGroupAdmins(participants) {
  let admins = [];
  for (let i of participants) {
    i.admin === "superadmin"
      ? admins.push(i.id)
      : i.admin === "admin"
      ? admins.push(i.id)
      : "";
  }
  return admins || [];
}

// FUNCTION

function hitungmundur(bulan, tanggal) {
  let from = new Date(`${bulan} ${tanggal}, 2023 00:00:00`).getTime();
  let now = Date.now();
  let distance = from - now;
  let days = Math.floor(distance / (1000 * 60 * 60 * 24));
  let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((distance % (1000 * 60)) / 1000);
  return (
    days + "Hari " + hours + "Jam " + minutes + "Menit " + seconds + "Detik"
  );
}

function msToDate(mse) {
  temp = mse;
  days = Math.floor(mse / (24 * 60 * 60 * 1000));
  daysms = mse % (24 * 60 * 60 * 1000);
  hours = Math.floor(daysms / (60 * 60 * 1000));
  hoursms = mse % (60 * 60 * 1000);
  minutes = Math.floor(hoursms / (60 * 1000));
  minutesms = mse % (60 * 1000);
  sec = Math.floor(minutesms / 1000);
  return days + " Days " + hours + " Hours " + minutes + " Minutes";
}

const isUrl = (url) => {
  return url.match(
    new RegExp(
      /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/,
      "gi"
    )
  );
};

const sleep = async (ms) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

const getRandom = (ext) => {
  return `${Math.floor(Math.random() * 10000)}${ext}`;
};

const runtime = function (seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600 * 24));
  var h = Math.floor((seconds % (3600 * 24)) / 3600);
  var m = Math.floor((seconds % 3600) / 60);
  var s = Math.floor(seconds % 60);
  var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
};

const jsonformat = (string) => {
  return JSON.stringify(string, null, 2);
};

async function UploadDulu(medianya, options = {}) {
  const { ext } = (await fromBuffer(medianya)) || options.ext;
  var form = new FormData();
  form.append("file", medianya, "tmp." + ext);
  let jsonnya = await fetch("https://tenaja.zeeoneofc.repl.co/upload", {
    method: "POST",
    body: form,
  }).then((response) => response.json());
  return jsonnya;
}

const tanggal = (numer) => {
  myMonths = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember",
  ];
  myDays = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum’at", "Sabtu"];
  var tgl = new Date(numer);
  var day = tgl.getDate();
  bulan = tgl.getMonth();
  var thisDay = tgl.getDay(),
    thisDay = myDays[thisDay];
  var yy = tgl.getYear();
  var year = yy < 1000 ? yy + 1900 : yy;
  const time = moment.tz("Asia/Jakarta").format("DD/MM HH:mm:ss");
  let d = new Date();
  let locale = "id";
  let gmt = new Date(0).getTime() - new Date("1 January 1970").getTime();
  let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][
    Math.floor((d * 1 + gmt) / 84600000) % 5
  ];

  return `${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`;
};

module.exports = alpha = async (
  alpha,
  m,
  chatUpdate,
  store,
  opengc,
  antilink,
  antiwame,
  antilink2,
  antiwame2,
  set_welcome_db,
  set_left_db,
  set_proses,
  set_done,
  set_open,
  set_close,
  sewa,
  _welcome,
  _left,
  db_respon_list
) => {
  try {
    var body =
      m.mtype === "conversation"
        ? m.message.conversation
        : m.mtype == "imageMessage"
        ? m.message.imageMessage.caption
        : m.mtype == "videoMessage"
        ? m.message.videoMessage.caption
        : m.mtype == "extendedTextMessage"
        ? m.message.extendedTextMessage.text
        : m.mtype == "buttonsResponseMessage"
        ? m.message.buttonsResponseMessage.selectedButtonId
        : m.mtype == "listResponseMessage"
        ? m.message.listResponseMessage.singleSelectReply.selectedRowId
        : m.mtype == "templateButtonReplyMessage"
        ? m.message.templateButtonReplyMessage.selectedId
        : m.mtype === "messageContextInfo"
        ? m.message.buttonsResponseMessage?.selectedButtonId ||
          m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
          m.text
        : ""; //omzee
    var budy = typeof m.text == "string" ? m.text : "";
    const isCmd = /^[���׶������_=|~!?#/$%^&.+-,\\\�^]/.test(body);
    const prefix = isCmd ? budy[0] : "";
    const command = isCmd
      ? body.slice(1).trim().split(" ").shift().toLowerCase()
      : "";
    const args = body.trim().split(/ +/).slice(1);
    const pushname = m.pushName || "No Name";
    const botNumber = await alpha.decodeJid(alpha.user.id);
    const isCreator = [
      botNumber,
      ...global.owner,
    ]
      .map((v) => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
      .includes(m.sender);
    const text = (q = args.join(" "));
    const salam = moment(Date.now())
      .tz("Asia/Jakarta")
      .locale("id")
      .format("a");
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    const isMedia = /image|video|sticker|audio/.test(mime);
    const groupMetadata = m.isGroup
      ? await alpha.groupMetadata(m.chat).catch((e) => {})
      : "";
    const groupName = m.isGroup ? groupMetadata.subject : "";
    const participants = m.isGroup ? await groupMetadata.participants : "";
    const from = mek.key.remoteJid;
    const numberReply =
      mek.message?.extendedTextMessage?.contextInfo?.participant?.replace(
        /[^0-9]/g,
        ""
      ) ?? mek.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo?.participant.replace(
        /[^0-9]/g,
        ""
      ) ?? "";
      const textReply =
      mek.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.extendedTextMessage?.text ??
      mek.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.extendedTextMessage?.text ??
      mek.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.conversation ??
      mek.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.ephemeralMessage?.conversation ??
      mek.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.ephemeralMessage?.message?.extendedTextMessage?.text ??
      "";
    const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : "";
    const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase();
    const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
    const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
    const isSewa = checkSewaGroup(m.chat, sewa);
    const isAntiLink = antilink.includes(m.chat) ? true : false;
    const isAntiWame = antiwame.includes(m.chat) ? true : false;
    const isAntiLink2 = antilink2.includes(m.chat) ? true : false;
    const isAntiWame2 = antiwame2.includes(m.chat) ? true : false;
    const isWelcome = _welcome.includes(m.chat);
    const isLeft = _left.includes(m.chat);
    const time = moment(Date.now())
      .tz("Asia/Jakarta")
      .locale("id")
      .format("HH:mm:ss z");
    const isAfkOn = afk.checkAfkUser(m.sender, _afk);

    const reply = async (text) => {
      return await alpha.sendFakeLink(m.chat, text, salam, pushname, m);
    };

    const fkontak = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(from ? { remoteJid: "status@broadcast" } : {}),
      },
      message: {
        contactMessage: {
          displayName: `FOLLOW : _ZHLNT_\n`,
          vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;alphaBot,;;;\nFN:${pushname},\nitem1.TEL;waid=${
            m.sender.split("@")[0]
          }:${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
          jpegThumbnail: {
            url: "https://telegra.ph/file/33e79ab21ec0446cc3e4f.jpg",
          },
        },
      },
    };
    function parseMention(text = "") {
      return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
        (v) => v[1] + "@s.whatsapp.net"
      );
    }

    async function getGcName(groupID) {
      try {
        let data_name = await alpha.groupMetadata(groupID);
        return data_name.subject;
      } catch (err) {
        return "-";
      }
    }

    if (m.message) {
      console.log(
        chalk.black(chalk.bgWhite("[ PESAN ]")),
        chalk.black(chalk.bgGreen(new Date())),
        chalk.black(chalk.bgBlue(budy || m.mtype)) +
          "\n" +
          chalk.magenta("=> From"),
        chalk.green(pushname),
        chalk.yellow(m.sender) + "\n" + chalk.blueBright("=> In"),
        chalk.green(m.isGroup ? pushname : "Chat Pribadi", m.chat)
      );
    }

    if (m.isGroup) {
      expiredCheck(alpha, sewa);
    }
    function pickRandom(list) {
      return list[Math.floor(Math.random() * list.length)];
    }

    //TIME
    const xtime = moment.tz("Asia/Kolkata").format("HH:mm:ss");
    const xdate = moment.tz("Asia/Kolkata").format("DD/MM/YYYY");
    const time2 = moment().tz("Asia/Kolkata").format("HH:mm:ss");
    if (time2 < "23:59:00") {
      var jer = `Good Night `;
    }
    if (time2 < "19:00:00") {
      var jer = `Good Evening `;
    }
    if (time2 < "18:00:00") {
      var jer = `Good Evening `;
    }
    if (time2 < "15:00:00") {
      var jer = `Good Afternoon `;
    }
    if (time2 < "11:00:00") {
      var jer = `Good Morning `;
    }
    if (time2 < "05:00:00") {
      var jer = `Good Morning `;
    }

    //autotyper all
    if (global.autoTyping) {
      if (m.chat) {
        alpha.sendPresenceUpdate("composing", m.chat);
      }
    }

    if (isAntiLink) {
      if (budy.match(`chat.whatsapp.com`)) {
        reply(
          `*「 ANTI LINK 」*\n\nLink grup detected, maaf kamu akan di kick !`
        );
        if (!isBotAdmins) return reply(`Upsss... gajadi, bot bukan admin`);
        let gclink =
          `https://chat.whatsapp.com/` + (await alpha.groupInviteCode(m.chat));
        let isLinkThisGc = new RegExp(gclink, "i");
        let isgclink = isLinkThisGc.test(m.text);
        if (isgclink) return reply(`Upsss... gak jadi, untung link gc sendiri`);
        if (isAdmins)
          return reply(`Upsss... gak jadi, kasian adminnya klo di kick`);
        if (isCreator)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        if (m.key.fromMe)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        await alpha.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,

            fromMe: false,
            id: m.key.id,
            participant: m.key.participant,
          },
        });
        alpha.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      }
    }
    if (isAntiLink2) {
      if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return; //reply(`Upsss... gajadi, bot bukan admin`)
        let gclink =
          `https://chat.whatsapp.com/` + (await alpha.groupInviteCode(m.chat));
        let isLinkThisGc = new RegExp(gclink, "i");
        let isgclink = isLinkThisGc.test(m.text);
        if (isgclink) return; //reply(`Upsss... gak jadi, untung link gc sendiri`)
        if (isAdmins) return; //reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return; //reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return; //reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        await alpha.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,

            fromMe: false,
            id: m.key.id,
            participant: m.key.participant,
          },
        });
      }
    }
    if (isAntiWame) {
      if (budy.match(`wa.me/`)) {
        reply(`*「 ANTI WA ME 」*\n\nWa Me detected, maaf kamu akan di kick !`);
        if (!isBotAdmins) return reply(`Upsss... gajadi, bot bukan admin`);
        if (isAdmins)
          return reply(`Upsss... gak jadi, kasian adminnya klo di kick`);
        if (isCreator)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        if (m.key.fromMe)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        await alpha.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,

            fromMe: false,
            id: m.key.id,
            participant: m.key.participant,
          },
        });
        alpha.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      }
    }
    if (isAntiWame2) {
      if (budy.match(`wa.me/`)) {
        if (!isBotAdmins) return; //reply(`Upsss... gajadi, bot bukan admin`)
        if (isAdmins) return; //reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return; //reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return; //reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        await alpha.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,

            fromMe: false,
            id: m.key.id,
            participant: m.key.participant,
          },
        });
      }
    }
    if (isAntiWame) {
      if (budy.includes(`Wa.me/` || `Wa.me/`)) {
        reply(`*「 ANTI WA ME 」*\n\nWa Me detected, maaf kamu akan di kick !`);
        if (!isBotAdmins) return reply(`Upsss... gajadi, bot bukan admin`);
        if (isAdmins)
          return reply(`Upsss... gak jadi, kasian adminnya klo di kick`);
        if (isCreator)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        if (m.key.fromMe)
          return reply(`Upsss... gak jadi, kasian owner ku klo di kick`);
        alpha.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      }
    }

    if (
      isAlreadyResponList(
        m.isGroup ? m.chat : botNumber,
        body.toLowerCase(),
        db_respon_list
      )
    ) {
      var get_data_respon = getDataResponList(
        m.isGroup ? m.chat : botNumber,
        body.toLowerCase(),
        db_respon_list
      );
      if (get_data_respon.isImage === false) {
        alpha.sendMessage(
          m.chat,
          {
            text: sendResponList(
              m.isGroup ? m.chat : botNumber,
              body.toLowerCase(),
              db_respon_list
            ),
          },
          {
            quoted: m,
          }
        );
      } else {
        alpha.sendMessage(
          m.chat,
          {
            image: await getBuffer(get_data_respon.image_url),
            caption: get_data_respon.response,
          },
          {
            quoted: m,
          }
        );
      }
    }

    const kontak = {
      key: {
        participant: `0@s.whatsapp.net`,
        ...(from
          ? {
              remoteJid: `6283136505591-1614953337@g.us`,
            }
          : {}),
      },
      message: {
        contactMessage: {
          displayName: `${pushname}`,
          vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname},\nitem1.TEL;waid=${
            m.sender.split("@")[0]
          }:${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
          jpegThumbnail: pp_bot,
          thumbnail: pp_bot,
          sendEphemeral: true,
        },
      },
    };
    const reSize = async (buffer, ukur1, ukur2) => {
      return new Promise(async (resolve, reject) => {
        let jimp = require("jimp");
        var baper = await jimp.read(buffer);
        var ab = await baper
          .resize(ukur1, ukur2)
          .getBufferAsync(jimp.MIME_JPEG);
        resolve(ab);
      });
    };
    // Auto Read & Presence Online
    if (!m.key.fromMe && global.autoread) {
      const readkey = {
        remoteJid: m.chat,
        id: m.key.id,
        participant: m.isGroup ? m.key.participant : undefined,
      };
      await alpha.readMessages([readkey]);
    }

    alpha.sendPresenceUpdate("available", m.chat);

    // Auto Block +212
    if (m.sender.startsWith("212") && global.autoblok212 === true) {
      return alpha.updateBlockStatus(m.sender, "block");
    }
    if (m.isGroup && !m.key.fromMe) {
      let mentionUser = [
        ...new Set([
          ...(m.mentionedJid || []),
          ...(m.quoted ? [m.quoted.sender] : []),
        ]),
      ];
      for (let ment of mentionUser) {
        if (afk.checkAfkUser(ment, _afk)) {
          let getId2 = afk.getAfkId(ment, _afk);
          let getReason2 = afk.getAfkReason(getId2, _afk);
          let getTimee = Date.now() - afk.getAfkTime(getId2, _afk);
          let heheh2 = ms(getTimee);
          reply(
            `Jangan tag, dia sedang afk\n\n*Reason :* ${getReason2}\n*Sejak :* ${heheh2.hours} jam, ${heheh2.minutes} menit, ${heheh2.seconds} detik yg lalu\n`
          );
        }
      }
      if (afk.checkAfkUser(m.sender, _afk)) {
        let getId = afk.getAfkId(m.sender, _afk);
        let getReason = afk.getAfkReason(getId, _afk);
        let getTime = Date.now() - afk.getAfkTime(getId, _afk);
        let heheh = ms(getTime);
        _afk.splice(afk.getAfkPosition(m.sender, _afk), 1);
        fs.writeFileSync("./database/afk.json", JSON.stringify(_afk));
        alpha.sendTextWithMentions(
          m.chat,
          `@${
            m.sender.split("@")[0]
          } telah kembali dari afk\n\n*Reason :* ${getReason}\n*Selama :* ${
            heheh.hours
          } jam ${heheh.minutes} menit ${heheh.seconds} detik\n`,
          m
        );
      }
    }

    switch (command) {
      case "owner":
      case "creator":
        {
          alpha.sendContact(m.chat, global.owner, m);
        }
        break;
      case "list":
      case "store":
        {
          if (db_respon_list.length === 0)
            return reply(`Belum ada list message di database`);
          if (
            !isAlreadyResponListGroup(
              m.isGroup ? m.chat : botNumber,
              db_respon_list
            )
          )
            return reply(
              `Belum ada list message yang terdaftar di group/chat ini`
            );
          let teks = `Halo @${
            m.sender.split("@")[0]
          } berikut beberapa list yang tersedia saat ini.\n\n`;
          for (let i of db_respon_list) {
            if (i.id === (m.isGroup ? m.chat : botNumber)) {
              teks += `- ${i.key}\n`;
            }
          }
          teks += `\n\nUntuk melihat detail produk, silahkan kirim nama produk yang ada pada list di atas. Misalnya kamu ingin melihat detail produk dari ${db_respon_list[0].key}, maka kirim pesan ${db_respon_list[0].key} kepada bot`;
          alpha.sendMessage(
            m.chat,
            { text: teks, mentions: [m.sender] },
            { quoted: m }
          );
        }
        break;
      case "dellist":
        {
          // if (!m.isGroup) return reply('Fitur Khusus Group!')
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin & owner!");
          if (db_respon_list.length === 0)
            return reply(`Belum ada list message di database`);
          if (!text)
            return reply(
              `Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${
                prefix + command
              } hello`
            );
          if (
            !isAlreadyResponList(
              m.isGroup ? m.chat : botNumber,
              q.toLowerCase(),
              db_respon_list
            )
          )
            return reply(
              `List respon dengan key *${q}* tidak ada di database!`
            );
          delResponList(
            m.isGroup ? m.chat : botNumber,
            q.toLowerCase(),
            db_respon_list
          );
          reply(`Sukses delete list message dengan key *${q}*`);
        }
        break;
      case "addlist":
        {
          //if (!m.isGroup) return reply('Fitur Khusus Group!')
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin & owner!");
          var args1 = q.split("|")[0].toLowerCase();
          var args2 = q.split("|")[1];
          if (!q.includes("|"))
            return reply(
              `Gunakan dengan cara ${command} *key|response*\n\n_Contoh_\n\n${command} tes|apa`
            );
          if (
            isAlreadyResponList(
              m.isGroup ? m.chat : botNumber,
              args1,
              db_respon_list
            )
          )
            return reply(
              `List respon dengan key : *${args1}* sudah ada di chat ini.`
            );
          if (m.isGroup) {
            if (/image/.test(mime)) {
              let media = await alpha.downloadAndSaveMediaMessage(quoted);
              let mem = await TelegraPh(media);
              addResponList(m.chat, args1, args2, true, mem, db_respon_list);
              reply(`Sukses set list message dengan key : *${args1}*`);
              if (fs.existsSync(media)) fs.unlinkSync(media);
            } else {
              addResponList(m.chat, args1, args2, false, "-", db_respon_list);
              reply(`Sukses set list message dengan key : *${args1}*`);
            }
          } else {
            if (/image/.test(mime)) {
              let media = await alpha.downloadAndSaveMediaMessage(quoted);
              let mem = await TelegraPh(media);
              addResponList(botNumber, args1, args2, true, mem, db_respon_list);
              reply(`Sukses set list message dengan key : *${args1}*`);
              if (fs.existsSync(media)) fs.unlinkSync(media);
            } else {
              addResponList(
                botNumber,
                args1,
                args2,
                false,
                "-",
                db_respon_list
              );
              reply(`Sukses set list message dengan key : *${args1}*`);
            }
          }
        }
        break;
      case "updatelist":
      case "update":
        {
          // if (!m.isGroup) return reply('Fitur Khusus Group!')
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin & owner!");
          var args1 = q.split("|")[0].toLowerCase();
          var args2 = q.split("|")[1];
          if (!q.includes("|"))
            return reply(
              `Gunakan dengan cara ${command} *key|response*\n\n_Contoh_\n\n${command} tes|apa`
            );
          if (
            !isAlreadyResponListGroup(
              m.isGroup ? m.chat : botNumber,
              db_respon_list
            )
          )
            return reply(
              `Maaf, untuk key *${args1}* belum terdaftar di chat ini`
            );
          if (/image/.test(mime)) {
            let media = await alpha.downloadAndSaveMediaMessage(quoted);
            let mem = await TelegraPh(media);
            updateResponList(
              m.isGroup ? m.chat : botNumber,
              args1,
              args2,
              true,
              mem,
              db_respon_list
            );
            reply(`Sukses update respon list dengan key *${args1}*`);
            if (fs.existsSync(media)) fs.unlinkSync(media);
          } else {
            updateResponList(
              m.isGroup ? m.chat : botNumber,
              args1,
              args2,
              false,
              "-",
              db_respon_list
            );
            reply(`Sukses update respon list dengan key *${args1}*`);
          }
        }
        break;
      case "jeda":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins)
            return reply("Jadikan bot sebagai admin terlebih dahulu");
          if (!text)
            return reply(
              `kirim ${command} waktu\nContoh: ${command} 30m\n\nlist waktu:\ns = detik\nm = menit\nh = jam\nd = hari`
            );
          opengc[m.chat] = { id: m.chat, time: Date.now() + toMS(text) };
          fs.writeFileSync("./database/opengc.json", JSON.stringify(opengc));
          alpha
            .groupSettingUpdate(m.chat, "announcement")
            .then((res) => reply(`Sukses, group akan dibuka ${text} lagi`))
            .catch((err) => reply("Error"));
        }
        break;
      case "tambah":
        {
          if (!text.includes("+"))
            return reply(
              `Gunakan dengan cara ${command} *angka* + *angka*\n\n_Contoh_\n\n${command} 1+2`
            );
          arg = args.join(" ");
          atas = arg.split("+")[0];
          bawah = arg.split("+")[1];
          var nilai_one = Number(atas);
          var nilai_two = Number(bawah);
          reply(`${nilai_one + nilai_two}`);
        }
        break;
      case "kurang":
        {
          if (!text.includes("-"))
            return reply(
              `Gunakan dengan cara ${command} *angka* - *angka*\n\n_Contoh_\n\n${command} 1-2`
            );
          arg = args.join(" ");
          atas = arg.split("-")[0];
          bawah = arg.split("-")[1];
          var nilai_one = Number(atas);
          var nilai_two = Number(bawah);
          reply(`${nilai_one - nilai_two}`);
        }
        break;
      case "kali":
        {
          if (!text.includes("*"))
            return reply(
              `Gunakan dengan cara ${command} *angka* * *angka*\n\n_Contoh_\n\n${command} 1*2`
            );
          arg = args.join(" ");
          atas = arg.split("*")[0];
          bawah = arg.split("*")[1];
          var nilai_one = Number(atas);
          var nilai_two = Number(bawah);
          reply(`${nilai_one * nilai_two}`);
        }
        break;
      case "bagi":
        {
          if (!text.includes("/"))
            return reply(
              `Gunakan dengan cara ${command} *angka* / *angka*\n\n_Contoh_\n\n${command} 1/2`
            );
          arg = args.join(" ");
          atas = arg.split("/")[0];
          bawah = arg.split("/")[1];
          var nilai_one = Number(atas);
          var nilai_two = Number(bawah);
          reply(`${nilai_one / nilai_two}`);
        }
        break;
      case "setproses":
      case "setp":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${
                prefix + command
              } Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `
            );
          if (isSetProses(m.isGroup ? m.chat : botNumber, set_proses))
            return reply(`Set proses already active`);
          addSetProses(text, m.isGroup ? m.chat : botNumber, set_proses);
          alpha.sendMessage(
            m.chat,
            { text: "Done Set Proses" },
            { quoted: fkontak }
          );
        }
        break;
      case "changeproses":
      case "changep":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${
                prefix + command
              } Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `
            );
          if (isSetProses(m.isGroup ? m.chat : botNumber, set_proses)) {
            changeSetProses(text, m.isGroup ? m.chat : botNumber, set_proses);
            alpha.sendMessage(
              m.chat,
              { text: "Sukses Ubah Set Proses" },
              { quoted: fkontak }
            );
          } else {
            addSetProses(text, m.isGroup ? m.chat : botNumber, set_proses);
            alpha.sendMessage(
              m.chat,
              { text: "Sukses Ubah Set Proses" },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "delsetproses":
      case "delsetp":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!isSetProses(m.isGroup ? m.chat : botNumber, set_proses))
            return reply(`Belum ada set proses di gc ini`);
          removeSetProses(m.isGroup ? m.chat : botNumber, set_proses);
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Delete Set Proses" },
            { quoted: fkontak }
          );
        }
        break;
      case "setdone": {
        if (!(m.isGroup ? isAdmins : isCreator))
          return reply("Fitur Khusus admin!");
        if (!text)
          return reply(
            `Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${
              prefix + command
            } Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `
          );
        if (isSetDone(m.isGroup ? m.chat : botNumber, set_done))
          return reply(`Udh set done sebelumnya`);
        addSetDone(text, m.isGroup ? m.chat : botNumber, set_done);
        reply(`Sukses set done!`);
        break;
      }
      case "changedone":
      case "changed":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${
                prefix + command
              } Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `
            );
          if (isSetDone(m.isGroup ? m.chat : botNumber, set_done)) {
            changeSetDone(text, m.isGroup ? m.chat : botNumber, set_done);
            reply(`Sukses ubah set done!`);
          } else {
            addSetDone(text, m.isGroup ? m.chat : botNumber, set_done);
            reply(`Sukses ubah set done!`);
          }
        }
        break;
      case "delsetdone":
      case "delsetd":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!isSetDone(m.isGroup ? m.chat : botNumber, set_done))
            return reply(`Belum ada set done di gc ini`);
          removeSetDone(m.isGroup ? m.chat : botNumber, set_done);
          reply(`Sukses delete set done`);
        }
        break;
      case "p":
      case "proses":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!m.quoted) return reply("Reply pesanan yang akan proses");
          let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1];
          let proses = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Pending\`\`\`\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!`;
          const getTextP = getTextSetProses(
            m.isGroup ? m.chat : botNumber,
            set_proses
          );
          if (getTextP !== undefined) {
            var anunya = getTextP
              .replace("@pesanan", tek ? tek : "-")
              .replace("@user", "@" + m.quoted.sender.split("@")[0])
              .replace("@jam", time)
              .replace("@tanggal", tanggal(new Date()))
              .replace("@user", "@" + m.quoted.sender.split("@")[0]);
            alpha.sendTextWithMentions(m.chat, anunya, m);
          } else {
            alpha.sendTextWithMentions(
              m.chat,
              proses
                .replace("@pesanan", tek ? tek : "-")
                .replace("@user", "@" + m.quoted.sender.split("@")[0])
                .replace("@jam", time)
                .replace("@tanggal", tanggal(new Date()))
                .replace("@user", "@" + m.quoted.sender.split("@")[0]),
              m
            );
          }
        }
        break;
      case "d":
      case "done":
        {
          if (!(m.isGroup ? isAdmins : isCreator))
            return reply("Fitur Khusus admin!");
          if (!m.quoted) return reply("Reply pesanan yang telah di proses");
          let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1];
          let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Berhasil\`\`\`\n\nTerimakasih @user Next Order ya🙏`;
          const getTextD = getTextSetDone(
            m.isGroup ? m.chat : botNumber,
            set_done
          );
          if (getTextD !== undefined) {
            var anunya = getTextD
              .replace("@pesanan", tek ? tek : "-")
              .replace("@user", "@" + m.quoted.sender.split("@")[0])
              .replace("@jam", time)
              .replace("@tanggal", tanggal(new Date()))
              .replace("@user", "@" + m.quoted.sender.split("@")[0]);
            alpha.sendTextWithMentions(m.chat, anunya, m);
          } else {
            alpha.sendTextWithMentions(
              m.chat,
              sukses
                .replace("@pesanan", tek ? tek : "-")
                .replace("@user", "@" + m.quoted.sender.split("@")[0])
                .replace("@jam", time)
                .replace("@tanggal", tanggal(new Date()))
                .replace("@user", "@" + m.quoted.sender.split("@")[0]),
              m
            );
          }
        }
        break;
      case "setopen":
        {
          if (!m.isGroup) return m.reply("Fitur Khusus Group!");
          if (!isCreator) return m.reply("Fitur Khusus owner!");
          if (!text)
            return m.reply(
              `Gunakan dengan cara ${
                prefix + command
              } *teks open*\n\n_Contoh_\n\n${
                prefix + command
              } Halo Semuanya, group sudah buka`
            );
          if (isSetOpen(m.chat, set_open))
            return m.reply(`Set open sudah ada sebelumnya`);
          addSetOpen(text, m.chat, set_open);
          reply(` Done set open!`);
        }
        break;
      case "changeopen":
      case "changesetopen":
        if (!m.isGroup) return m.reply("Fitur Khusus Group!");
        if (!isCreator) return m.reply("Fitur Khusus owner!");
        if (!text)
          return m.reply(
            `Gunakan dengan cara ${
              prefix + command
            } *teks open*\n\n_Contoh_\n\n${
              prefix + command
            } Halo Semuanya, group sudah buka`
          );
        if (isSetOpen(m.chat, set_open)) {
          changeSetOpen(text, m.chat, set_open);
          reply(`Sukses ubah set open teks!`);
        } else {
          addSetOpen(text, m.chat, set_open);
          reply(`Sukses ubah set open teks!`);
        }
        break;
      case "delsetopen":
        if (!m.isGroup) return m.reply("Fitur Khusus Group!");
        if (!isCreator) return m.reply("Fitur Khusus owner!");
        if (!isSetOpen(m.chat, set_open))
          return m.reply(`Belum ada set open di sini..`);
        removeSetOpen(m.chat, set_open);
        reply(`Sukses delete set open`);
        break;
      case "setclose":
        {
          if (!m.isGroup) return m.reply("Fitur Khusus Group!");
          if (!isCreator) return m.reply("Fitur Khusus owner!");
          if (!text)
            return m.reply(
              `Gunakan dengan cara ${
                prefix + command
              } *teks close*\n\n_Contoh_\n\n${
                prefix + command
              } Halo Semuanya, group close dulu ya`
            );
          if (isSetClose(m.chat, set_close))
            return m.reply(`Set close sudah ada sebelumnya`);
          addSetClose(text, m.chat, set_close);
          reply(` Done set close!`);
        }
        break;
      case "changeclose":
      case "changesetclose":
        if (!m.isGroup) return m.reply("Fitur Khusus Group!");
        if (!isCreator) return m.reply("Fitur Khusus owner!");
        if (!text)
          return m.reply(
            `Gunakan dengan cara ${
              prefix + command
            } *teks close*\n\n_Contoh_\n\n${
              prefix + command
            } Halo Semuanya, group close dulu ya`
          );
        if (isSetClose(m.chat, set_close)) {
          changeSetClose(text, m.chat, set_close);
          reply(`Sukses ubah set close teks!`);
        } else {
          addSetClose(text, m.chat, set_close);
          reply(`Sukses ubah set close teks!`);
        }
        break;
      case "delsetclose":
        if (!m.isGroup) return m.reply("Fitur Khusus Group!");
        if (!isCreator) return m.reply("Fitur Khusus owner!");
        if (!isSetClose(m.chat, set_close))
          return m.reply(`Belum ada set close di sini..`);
        removeSetClose(m.chat, set_close);
        reply(`Sukses delete set close`);
        break;
      case "welcome":
        {
          if (global.welcome || isWelcome) {
          }
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (args[0] === "on") {
            if (isWelcome) return reply(`Udah on`);
            _welcome.push(m.chat);
            fs.writeFileSync(
              "./database/welcome.json",
              JSON.stringify(_welcome, null, 2)
            );
            alpha.sendMessage(
              m.chat,
              { text: "Sukses Mengaktifkan Welcome" },
              { quoted: fkontak }
            );
          } else if (args[0] === "off") {
            if (!isWelcome) return reply(`Udah off`);
            let anu = _welcome.indexOf(m.chat);
            _welcome.splice(anu, 1);
            fs.writeFileSync(
              "./database/welcome.json",
              JSON.stringify(_welcome, null, 2)
            );
            alpha.sendMessage(
              m.chat,
              { text: "Sukses Nonaktifkan Welcome" },
              { quoted: fkontak }
            );
          } else {
            alpha.sendMessage(
              m.chat,
              {
                text: "Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on",
              },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "left":
      case "goodbye":
        {
          if (global.left || isLeft) {
          }
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (args[0] === "on") {
            if (isLeft) return reply(`Udah on`);
            _left.push(m.chat);
            fs.writeFileSync(
              "./database/left.json",
              JSON.stringify(_left, null, 2)
            );
            reply("Sukses mengaktifkan goodbye di grup ini");
          } else if (args[0] === "off") {
            if (!isLeft) return reply(`Udah off`);
            let anu = _left.indexOf(m.chat);
            _left.splice(anu, 1);
            fs.writeFileSync(
              "./database/welcome.json",
              JSON.stringify(_left, null, 2)
            );
            reply("Sukses menonaktifkan goodbye di grup ini");
          } else {
            alpha.sendMessage(
              m.chat,
              {
                text: "Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on",
              },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "setwelcome":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${command} *teks_welcome*\n\n_Contoh_\n\n${command} Halo @user, Selamat datang di @group`
            );
          if (isSetWelcome(m.chat, set_welcome_db))
            return reply(`Set welcome already active`);
          addSetWelcome(text, m.chat, set_welcome_db);
          reply(`Successfully set welcome!`);
        }
        break;
      case "changewelcome":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${command} *teks_welcome*\n\n_Contoh_\n\n${command} Halo @user, Selamat datang di @group`
            );
          if (isSetWelcome(m.chat, set_welcome_db)) {
            changeSetWelcome(q, m.chat, set_welcome_db);
            reply(`Sukses change set welcome teks!`);
          } else {
            addSetWelcome(q, m.chat, set_welcome_db);
            reply(`Sukses change set welcome teks!`);
          }
        }
        break;
      case "delsetwelcome":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!isSetWelcome(m.chat, set_welcome_db))
            return reply(`Belum ada set welcome di sini..`);
          removeSetWelcome(m.chat, set_welcome_db);
          reply(`Sukses delete set welcome`);
        }
        break;
      case "setleft":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${
                prefix + command
              } *teks_left*\n\n_Contoh_\n\n${
                prefix + command
              } Halo @user, Selamat tinggal dari @group`
            );
          if (isSetLeft(m.chat, set_left_db))
            return reply(`Set left already active`);
          addSetLeft(q, m.chat, set_left_db);
          reply(`Successfully set left!`);
        }
        break;
      case "changeleft":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!text)
            return reply(
              `Gunakan dengan cara ${
                prefix + command
              } *teks_left*\n\n_Contoh_\n\n${
                prefix + command
              } Halo @user, Selamat tinggal dari @group`
            );
          if (isSetLeft(m.chat, set_left_db)) {
            changeSetLeft(q, m.chat, set_left_db);
            reply(`Sukses change set left teks!`);
          } else {
            addSetLeft(q, m.chat, set_left_db);
            reply(`Sukses change set left teks!`);
          }
        }
        break;
      case "delsetleft":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isCreator && !isAdmins) return reply("Fitur Khusus owner!");
          if (!isSetLeft(m.chat, set_left_db))
            return reply(`Belum ada set left di sini..`);
          removeSetLeft(m.chat, set_left_db);
          reply(`Sukses delete set left`);
        }
        break;
      case "antiwame":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins)
            return reply("Jadikan bot sebagai admin terlebih dahulu");
          if (args[0] === "on") {
            if (isAntiWame) return reply(`Udah aktif`);
            antiwame.push(m.chat);
            fs.writeFileSync(
              "./database/antiwame.json",
              JSON.stringify(antiwame, null, 2)
            );
            reply("Successfully Activate Antiwame In This Group");
          } else if (args[0] === "off") {
            if (!isAntiWame) return reply(`Udah nonaktif`);
            let anu = antiwame.indexOf(m.chat);
            antiwame.splice(anu, 1);
            fs.writeFileSync(
              "./database/antiwame.json",
              JSON.stringify(antiwame, null, 2)
            );
            reply("Successfully Disabling Antiwame In This Group");
          } else {
            alpha.sendMessage(
              m.chat,
              {
                text: "Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on",
              },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "antilink":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins) return reply("Bot harus menjadi admin");
          if (args[0] === "on") {
            if (isAntiLink) return reply(`Udah aktif`);
            antilink.push(m.chat);
            fs.writeFileSync(
              "./database/antilink.json",
              JSON.stringify(antilink, null, 2)
            );
            reply("Successfully Activate Antilink In This Group");
          } else if (args[0] === "off") {
            if (!isAntiLink) return reply(`Udah nonaktif`);
            let anu = antilink.indexOf(m.chat);
            antilink.splice(anu, 1);
            fs.writeFileSync(
              "./database/antilink.json",
              JSON.stringify(antilink, null, 2)
            );
            reply("Successfully Disabling Antilink In This Group");
          } else {
            alpha.sendMessage(
              m.chat,
              {
                text: "Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on",
              },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "h":
      case "hidetag":
        {
          if (!m.isGroup) return reply("Khusus grup");
          if (!(isAdmins || isCreator)) return reply("Fitur khusus admin");
          let tek = m.quoted ? quoted.text : text ? text : "";
          alpha.sendMessage(
            m.chat,
            {
              text: tek,
              mentions: participants.map((a) => a.id),
            },
            {
              quoted: kontak,
            }
          );
        }
        break;
      case "sewa":
      case "sewabot":
        {
          reply(sewabot);
        }
        break;
      case "kick":
        {
          if (!m.isGroup) return reply("Hanya Dapat Di Gunakan Di Group");
          if (!isBotAdmins) return reply("Bot Bukan Admin");
          if (!isAdmins)
            return reply("Fitur Ini Hanya Dapat Di Gunakan Oleh Admin");
          let users = m.mentionedJid[0]
            ? m.mentionedJid[0]
            : m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await alpha
            .groupParticipantsUpdate(m.chat, [users], "remove")
            .then((res) => reply(jsonformat()))
            .catch((err) => reply(jsonformat)());
          alpha.sendMessage(
            m.chat,
            { text: "Mampus Gua Kick Lu !!!" },
            { quoted: fkontak }
          );
        }
        break;
      case "add":
        {
          if (!m.isGroup) return reply("Hanya Dapat Di Gunakan Di Group");
          if (!isBotAdmins) return reply("Bot Bukan Admin");
          if (!isAdmins)
            return reply("Fitur Ini Hanya Dapat Di Gunakan Oleh Admin");
          let users = m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await alpha
            .groupParticipantsUpdate(m.chat, [users], "add")
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)));
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Add Member" },
            { quoted: fkontak }
          );
        }
        break;
      case "promote": {
        if (!m.isGroup) return reply("Hanya Dapat Di Gunakan Di Group");
        if (!isBotAdmins) return reply("Bot Bukan Admin");
        if (!isAdmins)
          return reply("Fitur Ini Hanya Dapat Di Gunakan Oleh Admin");
        let users = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
          ? m.quoted.sender
          : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await alpha
          .groupParticipantsUpdate(m.chat, [users], "promote")
          .then((res) => reply(jsonformat(res)))
          .catch((err) => reply(jsonformat(err)));
        alpha.sendMessage(
          m.chat,
          {
            text: "Sukses Add Member Sebagai Admin Di Grub ${metadata.subject}",
          },
          { quoted: fkontak }
        );
      }
      case "demote":
        {
          if (!m.isGroup) return reply("Hanya Dapat Di Gunakan Di Group");
          if (!isBotAdmins) return reply("Bot Bukan Admin");
          if (!isAdmins)
            return reply("Fitur Ini Hanya Dapat Di Gunakan Oleh Admin");
          let users = m.mentionedJid[0]
            ? m.mentionedJid[0]
            : m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await alpha
            .groupParticipantsUpdate(m.chat, [users], "promote")
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)));
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Und Admin" },
            { quoted: fkontak }
          );
        }
        break;
      case "sc":
      case "script":
        {
          reply(
            `Mau Sc Nya Yah Kak ?,\n\nNih Sc Nya\nhttps://youtube.com/\n\nPemilik Sc Nya +6285336393488\nChat Jika Ada Kepentingan Saja !`
          );
        }
        break;
      case "tqto":
      case "thanksto":
        {
          reply(`╭─❒ 「 THANKS TO 」 
│○ Allah Swt.
│○ Myparents
│○ ZHULANT
│○ DapaZZ
╰❒`);
        }
        break;
      case "join":
        {
          if (!isCreator)
            return reply(`Fitur Ini Hanya Dapat Di Gunakan Oleh Owner`);
          if (!text) return reply(`Masukan Link Group !`);
          if (!isUrl(args[0]) && !args[0].includes("whatsapp.com"))
            return reply(`Link Eror !`);
          alpha.sendMessage(
            m.chat,
            { text: "Sedang Di Proses" },
            { quoted: fkontak }
          );
          let result = args[0].split("https://chat.whatsapp.com/")[1];
          await alpha
            .groupAcceptInvite(result)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)));
        }
        break;
      case "linkgroup":
      case "linkgc":
      case "gclink":
      case "grouplink":
        {
          if (!m.isGroup) throw reply(`Fitur Ini Khusus Group`);
          if (!isBotAdmins) throw reply(`Bot Bukan Admin`);
          alpha.sendMessage(
            m.chat,
            { text: "Sedang Di Proses" },
            { quoted: fkontak }
          );
          let response = await alpha.groupInviteCode(m.chat);
          alpha.sendText(
            m.chat,
            `https://chat.whatsapp.com/${response}\n\nGroup Link : ${groupMetadata.subject}`,
            m,
            { detectLink: true }
          );
        }
        break;
      case "revoke":
      case "resetlink":
      case "resetlinkgrup":
      case "resetlinkgroup":
      case "resetlinkgc":
        {
          if (!m.isGroup) throw reply(`Fitur Ini Khusus Group`);
          if (!isBotAdmins) throw reply(`Bot Bukan Admin`);
          if (!isAdmins && !isCreator) return reply(`Fitur Ini Khusus Admin !`);
          alpha.sendMessage(
            m.chat,
            { text: "Sedang Di Proses" },
            { quoted: fkontak }
          );
          alpha.groupRevokeInvite(m.chat);
          reply(`Done Reset Link Gc Nya Kak`);
        }
        break;
      case "delete":
      case "del":
        {
          if (!m.quoted) throw false;
          let { chat, fromMe, id, isBaileys } = m.quoted;
          if (!isBaileys) return "Pesan Itu Bukan Di kirim Oleh Bot";
          alpha.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: true,
              id: m.quoted.id,
              participant: m.quoted.sender,
            },
          });
        }
        break;
      case "kosong":
        {
          if (!isCreator) return `Fitur Ini Khusus Owner`;
          reply(`
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         `);
        }
        break;
      case "out":
        {
          if (!m.isGroup) throw reply(`Fitur Ini Khusus Group`);
          if (!isCreator) return reply(`Fitur Ini Khusus Owner`);
          await alpha
            .groupLeave(m.chat)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)));
        }
        break;
      case "public":
        {
          if (!isCreator) return `Fitur Ini Khusus Owner`;
          alpha.public = true;
          reply("*Sukses Ganti Bot Ke Mode Public*");
        }
        break;
      case "self":
        {
          if (!isCreator) return `Fitur Ini Khusus Owner`;
          alpha.public = false;
          reply(
            "*Sukses Ganti Bot Ke mode Self, Jika Mau Ganti Bot  Ke Mode Public Silahkan Ke Nomor Bot Ketik .public*"
          );
        }
        break;
      case "setnamegc":
      case "setnamagc":
        {
          if (!m.isGroup) return `Fitur Ini Khusus Group`;
          if (!isBotAdmins) return `Bot Bukan Admin`;
          if (!isAdmins) return `Fitur Ini Khusus Admin !`;
          if (!text) throw "Text Nya ?";
          await alpha
            .groupUpdateSubject(m.chat, text)
            .then((res) => reply(mess.success))
            .catch((err) => reply(jsonformat(err)));
        }
        break;
      case "setdesc":
      case "setdesk":
        {
          if (!m.isGroup) return `Fitur Ini Khusus Group`;
          if (!isBotAdmins) return `Bot Bukan Admin`;
          if (!isAdmins) return `Fitur Ini Khusus Admin !`;
          if (!text) throw "Text Nya ?";
          await alpha
            .groupUpdateDescription(m.chat, text)
            .then((res) => reply(mess.success))
            .catch((err) => reply(jsonformat(err)));
        }
        break;
      case "developer":
      case "dev":
        {
          reply(
            `Store Bot DEVELOPER\n\n\n2022-2023 Store Bot.\n\nWhatshapp\nJER: wa.me/6285336393488\n\nYOUTUBE:\nhttps://youtube.com/\n\n`
          );
        }
        break;
      case "addsewa":
        {
          if (!isCreator) return reply("Fitur khusus owner!");
          if (text < 2)
            return reply(
              `Gunakan dengan cara ${
                prefix + command
              } *linkgc waktu*\n\nContoh : ${command} https://chat.whatsapp.com/JanPql7MaMLa 30d\n\n*CATATAN:*\nd = hari (day)\nm = menit(minute)\ns = detik (second)\ny = tahun (year)\nh = jam (hour)`
            );
          if (!isUrl(args[0]))
            return reply("Link grup wa gk gitu modelnya cuy");
          var url = args[0];
          url = url.split("https://chat.whatsapp.com/")[1];
          if (!args[1]) return reply(`Waktunya?`);
          var data = await alpha.groupAcceptInvite(url);
          if (checkSewaGroup(data, sewa))
            return reply(`Bot sudah disewa oleh grup tersebut!`);
          addSewaGroup(data, args[1], sewa);
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Add Sewa Berwaktu" },
            { quoted: fkontak }
          );
        }
        break;
      case "delsewa":
        {
          if (!isCreator) return reply("Fitur khusus owner!");
          if (!m.isGroup)
            return reply(
              `Perintah ini hanya bisa dilakukan di Grup yang menyewa bot`
            );
          if (!isSewa) return reply(`Bot tidak disewa di Grup ini`);
          sewa.splice(getSewaPosition(m.chat, sewa), 1);
          fs.writeFileSync(
            "./database/sewa.json",
            JSON.stringify(sewa, null, 2)
          );
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Delete Sewa Di Grub Ini" },
            { quoted: fkontak }
          );
        }
        break;
      case "ceksewa":
      case "listsewa":
        {
          if (!isCreator) return reply("Emank Lu Owner Gua ?");
          let list_sewa_list = `*LIST SEWA*\n\n*Total:* ${sewa.length}\n\n`;
          let data_array = [];
          for (let x of sewa) {
            list_sewa_list += `*Name:* ${await getGcName(x.id)}\n*ID :* ${
              x.id
            }\n`;
            if (x.expired === "PERMANENT") {
              let ceksewa = "PERMANENT";
              list_sewa_list += `*Expire :* PERMANENT\n\n`;
            } else {
              let ceksewa = x.expired - Date.now();
              list_sewa_list += `*Expired :* ${msToDate(ceksewa)}\n\n`;
            }
          }
          alpha.sendMessage(m.chat, { text: list_sewa_list }, { quoted: m });
        }
        break;
      case "antiwame2":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins)
            return reply("Jadikan bot sebagai admin terlebih dahulu");
          if (args[0] === "on") {
            if (isAntiWame2) return reply(`Udah aktif`);
            antiwame2.push(m.chat);
            fs.writeFileSync(
              "./database/antiwame2.json",
              JSON.stringify(antiwame2, null, 2)
            );
            reply("Successfully Activate antiwame2 In This Group");
          } else if (args[0] === "off") {
            if (!isAntiWame2) return reply(`Udah nonaktif`);
            let anu = antiwame2.indexOf(m.chat);
            antiwame2.splice(anu, 1);
            fs.writeFileSync(
              "./database/antiwame2.json",
              JSON.stringify(antiwame2, null, 2)
            );
            reply("Successfully Disabling antiwame2 In This Group");
          } else {
            reply(
              `Kirim perintah ${prefix + command} on/off\n\nContoh: ${
                prefix + command
              } on`
            );
          }
        }
        break;
      case "antilink2":
        {
          if (!m.isGroup) return reply(`Fitur Ini Khusus Group`);
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins) return reply("Bot harus menjadi admin");
          if (args[0] === "on") {
            if (isAntiLink2) return reply(`Udah aktif`);
            antilink2.push(m.chat);
            fs.writeFileSync(
              "./database/antilink2.json",
              JSON.stringify(antilink2, null, 2)
            );
            reply("Successfully Activate antilink2 In This Group");
          } else if (args[0] === "off") {
            if (!isAntiLink2) return reply(`Udah nonaktif`);
            let anu = antilink2.indexOf(m.chat);
            antilink2.splice(anu, 1);
            fs.writeFileSync(
              "./database/antilink2.json",
              JSON.stringify(antilink2, null, 2)
            );
            reply("Successfully Disabling antilink2 In This Group");
          } else {
            reply(
              `Kirim perintah ${prefix + command} on/off\n\nContoh: ${
                prefix + command
              } on`
            );
          }
        }
        break;
      case "groupbot":
      case "grubbot":
      case "grupbot":
        {
          reply(grubbot);
        }
        break;
      case "smeme":
      case "stickmeme":
      case "stikmeme":
      case "stickermeme":
      case "stikermeme":
        if (!isBanned && !isCreator)
          return m.reply(
            `* Kamu Terkena Banned Oleh Owner*, Silahkan Hubungi Owner Meminta Untuk Di Unbanned`
          );

        if (!text)
          return reply(
            `Send/Reply Photo With Caption ${prefix + command} *text*`
          );
        if (/image/.test(mime)) {
          alpha.sendMessage(
            m.chat,
            { text: "Sedang Di Proses" },
            { quoted: fkontak }
          );
          mee = await alpha.downloadAndSaveMediaMessage(quoted);
          mem = await uptotelegra(mee);
          meme = `https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`;
          alpha.sendImageAsSticker(m.chat, meme, m, {
            packname: global.packname,
            author: global.author,
          });
        }
        break;
      case "cekidff":
        {
          if (!q)
            return reply(
              `Kirim perintah ${prefix + command} id\nContoh: ${
                prefix + command
              } 12345678`
            );
          var pack = q;
          stalkff(pack).then((i) => {
            if (i.status !== 200)
              return reply("Terjadi Kesalahan!!\nid ff tidak ditemukan");
            reply(`*STALKER FF*

*ID*: ${i.id}
*Nickname:* ${i.nickname}`);
          });
        }
        break;
      case "cekidml":
        {
          if (!q)
            return reply(
              `Kirim perintah ${prefix + command} id|zone\nContoh: ${
                prefix + command
              } 1234578|1234`
            );
          var id = q.split("|")[0];
          var zon = q.split("|")[1];
          if (!id) return reply("ID wajib di isi");
          if (!zon) return reply("ZoneID wajib di isi");
          stalkml(id, zon).then((i) => {
            if (i.status !== 200)
              return reply("Terjadi Kesalahan!!\nid/zone tidak ditemukan");
            reply(`*STALKER ML*
		
ID: ${id}
Zone: ${zon}
Nickname: ${i.nickname}`);
          });
        }
        break;
      case "sendlinkgc":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins) return reply("Bot Bukan Admin Cuy");
          if (!args[0])
            return reply(
              `Penggunaan ${prefix + command} nomor\nContoh ${
                prefix + command
              } 6283136394680`
            );
          bnnd = text.split("|")[0] + "@s.whatsapp.net";
          let response = await alpha.groupInviteCode(from);
          alpha.sendText(
            bnnd,
            `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`,
            m,
            { detectLink: true }
          );
          alpha.sendMessage(
            m.chat,
            { text: "Sukses Sendlinkgc Ke Nomor Itu" },
            { quoted: fkontak }
          );
        }
        break;
      case "assalamualaikum":
        {
          reply(`Waalaikumsalam`);
        }
        break;
      case "tagall":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins) return reply("Bot Bukan Admin Cuy");
          let teks = `╚» Tag All «╝ 
	
🌿 *Message : ${q ? q : "empty"}*\n\n`;
          for (let mem of participants) {
            teks += `@${mem.id.split("@")[0]}\n`;
          }
          alpha.sendMessage(
            m.chat,
            { text: teks, mentions: participants.map((a) => a.id) },
            { quoted: m }
          );
        }
        break;
      case "swm":
      case "stickerwm":
      case "wm":
      case "take":
        {
          if (!isBanned && !isCreator)
            return m.reply(
              `* Kamu Terkena Banned Oleh Owner*, Silahkan Hubungi Owner Meminta Untuk Di Unbanned`
            );

          if (!args.join(" "))
            return reply(`Contoh :\nswm ${global.author}|${global.packname}`);
          const swn = args.join(" ");
          const pcknm = swn.split("|")[0];
          const atnm = swn.split("|")[1];
          if (m.quoted.isAnimated === true) {
            alpha.downloadAndSaveMediaMessage(quoted, "gifee");
            alpha.sendMessage(
              from,
              { sticker: fs.readFileSync("gifee.webp") },
              { quoted: m }
            );
          } else if (/image/.test(mime)) {
            let media = await quoted.download();
            let encmedia = await alpha.sendImageAsSticker(m.chat, media, m, {
              packname: pcknm,
              author: global.atnm,
            });
            await fs.unlinkSync(encmedia);
          } else if (/video/.test(mime)) {
            if ((quoted.msg || quoted).seconds > 11)
              return reply("Maximum 10 seconds!");
            let media = await quoted.download();
            let encmedia = await alpha.sendVideoAsSticker(m.chat, media, m, {
              packname: pcknm,
              author: atnm,
            });
            await fs.unlinkSync(encmedia);
          } else {
            alpha.sendMessage(
              m.chat,
              {
                text: "Send Image/Video With Caption ${prefix + command}\nVideo Duration 1-9 Seconds",
              },
              { quoted: fkontak }
            );
          }
        }
        break;
      case "group":
      case "grup":
        {
          if (!m.isGroup) return reply("Fitur Khusus Group!");
          if (!isAdmins) return reply("Fitur Khusus admin!");
          if (!isBotAdmins)
            return reply("Jadikan bot sebagai admin terlebih dahulu");
          if (args[0] === "close") {
            await alpha
              .groupSettingUpdate(m.chat, "announcement")
              .then((res) => m.reply(`*Successfully Closed The Group*`))
              .catch((err) => m.reply(jsonformat(err)));
          } else if (args[0] === "open") {
            await alpha
              .groupSettingUpdate(m.chat, "not_announcement")
              .then((res) => m.reply(`*Successfully Opened The Group*`))
              .catch((err) => m.reply(jsonformat(err)));
          } else {
            reply(
              `Kirim perintah ${prefix + command} open/close\n\nContoh: ${
                prefix + command
              } open`
            );
          }
        }
        break;
      case "anticall":
        {
          if (!m.key.fromMe && !isCreator) return reply("Fitur khusus owner!");
          if (args[0] === "on") {
            if (global.anticall === true)
              return reply(`Sudah Di Aktifkan Sebelumnya`);
            global.anticall = true;
            reply(`Berhasil Mengaktifkan Anticall`);
          } else if (args[0] === "off") {
            if (global.anticall === false)
              return reply(`Sudah Di Nonaktifkan Sebelumnya`);
            global.anticall = false;
            reply(`Sukses Nonaktifkan Anticall`);
          } else {
            reply(
              `Kirim perintah ${prefix + command} on/off\n\nContoh: ${
                prefix + command
              } on`
            );
          }
        }
        break;
      case "qc":
        {
          //
          if (!quoted) {
            try {
              var ppuser = await alpha.profilePictureUrl(
                mentionUser[0],
                "image"
              );
            } catch {
              image: {
                url: ppuser;
              }
            }
            const getname = await alpha.getName(mentionUser[0]);
            const json = {
              type: "quote",
              format: "png",
              backgroundColor: "#FFFFFF",
              width: 512,
              height: 768,
              scale: 2,
              messages: [
                {
                  entities: [],
                  avatar: true,
                  from: {
                    id: 1,
                    name: getname,
                    photo: {
                      url: ppuser,
                    },
                  },
                  text: quotedMsg.chats,
                  replyMessage: {},
                },
              ],
            };
            const response = axios
              .post("https://bot.lyo.su/quote/generate", json, {
                headers: { "Content-Type": "application/json" },
              })
              .then((res) => {
                const buffer = Buffer.from(res.data.result.image, "base64");
                var opt = { packname: global.packname, author: global.author };
                alpha.sendImageAsSticker(from, buffer, m, opt);
              });
          } else if (q) {
            try {
              var ppuser = await alpha.profilePictureUrl(sender, "image");
            } catch {
              image: {
                url: ppuser;
              }
            }
            const json = {
              type: "quote",
              format: "png",
              backgroundColor: "#FFFFFF",
              width: 512,
              height: 768,
              scale: 2,
              messages: [
                {
                  entities: [],
                  avatar: true,
                  from: {
                    id: 1,
                    name: pushname,
                    photo: {
                      url: ppuser,
                    },
                  },
                  text: q,
                  replyMessage: {},
                },
              ],
            };
            const response = axios
              .post("https://bot.lyo.su/quote/generate", json, {
                headers: { "Content-Type": "application/json" },
              })
              .then((res) => {
                const buffer = Buffer.from(res.data.result.image, "base64");
                var opt = { packname: global.packname, author: global.author };
                alpha.sendImageAsSticker(from, buffer, m, opt);
              });
          } else {
            reply(
              `Kirim perintah ${command} text atau reply pesan dengan perintah ${command}`
            );
          }
        }
        break;
      case "setppgroup":
      case "setgcpp":
      case "setgrouppp":
        {
          if (!m.isGroup) return reply("Fitur Ini Khusus Group Blok !");
          if (!isAdmins && !isCreator)
            return reply("Fitur Ini Khusus Admin Blok !");
          if (!isBotAdmins) return reply("Bot Bukan Admin Lol !");
          if (!quoted) return reply(`Where is the picture?`);
          if (!/image/.test(mime))
            return reply(`Send/Reply Image With Caption ${prefix + command}`);
          if (/webp/.test(mime))
            return reply(`Send/Reply Image With Caption ${prefix + command}`);
          var mediz = await alpha.downloadAndSaveMediaMessage(
            quoted,
            "ppgc.jpeg"
          );
          if (args[0] == `/panjang`) {
            var { img } = await generateProfilePicture(mediz);
            await alpha.query({
              tag: "iq",
              attrs: {
                to: m.chat,
                type: "set",
                xmlns: "w:profile:picture",
              },
              content: [
                {
                  tag: "picture",
                  attrs: { type: "image" },
                  content: img,
                },
              ],
            });
            fs.unlinkSync(mediz);
            reply(`Success`);
          } else {
            var memeg = await alpha.updateProfilePicture(m.chat, {
              url: mediz,
            });
            fs.unlinkSync(mediz);
            reply(`Success`);
          }
        }
        break;
      case "menu":
      case "help":
        {
          alpha.sendMessage(from, {
            text: `Halo Kak @${
              m.sender.split("@")[0]
            }\nSaya ${namabot}, Saya Adalah Bot WhatsApp .\n\n*INFO-BOT* 
Creator : ${namaowner}
Bot Name : ${namabot}
TIME : ${xtime}
DATE : ${xdate}\n
${menunya(pushname)}`,
            mentions: [m.sender]
          });
        }
        break;
      case "afk":
        if (!m.isGroup) return reply("Fitur Ini Khusus Group Blok !");
        if (isAfkOn) return m.reply("Afk sudah diaktifkan sebelumnya");
        let reason = text ? text : "Nothing.";
        afk.addAfkUser(m.sender, Date.now(), reason, _afk);
        alpha.sendTextWithMentions(
          m.chat,
          `@${m.sender.split("@")[0]} sedang afk\nAlasan : ${reason}`,
          m
        );
        break;

      case "daftar": 
      await alpha.sendMessage(from, { text: await daftarAkun(m.sender.split('@')[0]) }, { quoted: m });
      break;

      case "infoakun":
        await alpha.sendMessage(from, { text: await userInfo(m.sender.split('@')[0]) }, { quoted: m });
        break;

      case "listproduk":
        await alpha.sendMessage(from, { text: await produkList() }, { quoted: m });
        break;

      case "tambahsaldo":

        if (!isCreator) {
          reply("*Fitur ini khusus owner*");
          return
        }

        const pesan = budy || m.mtype
        const args = pesan.split(" ");
        
        await alpha.sendMessage(from, { text: await tambahSaldo(numberReply, args[1]) }, { quoted: m });
        break;

      case "kurangsaldo":

        if (!isCreator) {
           reply("*Fitur ini khusus owner*");
           return
        }

        const pesann = budy || m.mtype
        const argss = pesann.split(" ");

        await alpha.sendMessage(from, { text: await kurangSaldo(numberReply,argss[1]) }, { quoted: m } )
        break;

      case "tambahstock":


      if (!isCreator) {
        reply("*Fitur ini khusus owner*");
        return
      }

        const pesannn = budy || m.mtype
        const argsss = pesannn.split(" ");
        
        await alpha.sendMessage(from, { text: await tambahStock(argsss[1],textReply) }, {quoted: m });
        break;

      case "kurangstock":

      if (!isCreator) {
        reply("*Fitur ini khusus owner*");
        return
      }

        await alpha.sendMessage(from, { text: await kurangStock(textReply) });
        break;

      case "order":
        const pesanOrder = budy || m.mtype
        const argsOrder = pesanOrder.toString().split(" ");

        console.log(argsOrder)

        await beliBarang(m.sender.split('@')[0],argsOrder[1],argsOrder[2],alpha,from)
        break;

      case "deposit":

        await alpha.sendMessage(from, { image: fs.readFileSync("./image/qris.jpeg"), caption: "*Panduan Deposit Manual*\n\n» Silahkan Transfer Ke Qris Sesuai Nominal yang anda inginkan\n\n» Silahkan kan screenshot bukti transfer, dan kirimkan bukti di grup\n\n» Jangan lupa Tag admin jika sudah Transfer\n\n*Metode Pembayaran*\n» Pembayaran deposit hanya melalui *QRIS DI PP GROUP*" }, { quoted: m } )
        break;

      default:
        if (budy.startsWith(">")) {
          if (!isCreator) return;
          try {
            let evaled = await eval(budy.slice(2));
            if (typeof evaled !== "string")
              evaled = require("util").inspect(evaled);
            await reply(evaled);
          } catch (err) {
            await reply(util.format(err));
          }
        }
    }
  } catch (err) {
    m.reply(util.format(err));
  }
};
