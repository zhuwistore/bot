const mongoose = require('mongoose');
const db = mongoose.connection;
require('../../settings')

async function connectDB() {
    try {
        await mongoose.connect(global.uriMongo, {
            dbName: "ZhulData"
        });
    } catch (error) {
        console.error("MongoDB connection error:", error);
    }
}

db.on("disconnected", () => {
    console.log("MongoDB connection closed ❌");
});

db.on("connected", () => {
    console.log("DATABASE SUDAH SIAP✅");
});

module.exports = connectDB;