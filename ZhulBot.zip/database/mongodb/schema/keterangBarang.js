const mongodb = require("mongoose");

const Schema = new mongodb.Schema(
    {
      code: String,
      keterangan: String
    },
    {
      collection: "Keterangan",
    }
);
  
const Keterangan = mongodb.model("Keterangan", Schema);

module.exports = Keterangan