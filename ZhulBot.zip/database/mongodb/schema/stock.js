const mongodb = require("mongoose");

const Schema = new mongodb.Schema(
  {
    code: String,
    data: String,
  },
  {
    collection: "Stock",
  }
);

const Stock = mongodb.model("Stock", Schema);

module.exports = Stock;