const fs = require('fs')

global.uriMongo = "mongodb+srv://zhulstoremandiri:igq6iqnjTXPwkVIq@zhuldata.c4zk8em.mongodb.net/?retryWrites=true&w=majority"
global.namabot = "Store Bot" // UBAH JADI NAMA LU
global.namaowner = "ZHULANT" // NAMA OWNER
global.footer_text = "© Store Bot" + namabot // NAMA BOT
global.pp_bot = fs.readFileSync("./image/allmenubot.jpg") // FOTO BOT MAX 50KB BIAR GA DELAY
global.qris = fs.readFileSync("./image/qris.jpeg") // FOTO QRIS MAX 50KB BIAR GA DELLAY
global.owner = ['6285336393488'] // UBAH NOMOR YANG MAU DI JADIKAN OWNER
// - \\
global.sessionName = 'session' // GAK USAH UBAH
global.prefa = ['', '!', '.', '🐦', '🐤', '🗿'] // GAK USAH UBAH
global.sewabot = ("Untuk sewa bot bisa chat owner kami 085336393488") // ISI HARGA SEWA BOT LU
global.script = ("-") // BEBAS ASAL JAN HAPUS
global.fakelink = "-" // bebas asal jan hapus
global.grubbot = (`-`) // GANTI LINK GRUB BOT LU \\
// FALSE OR TRUE \\
global.autoTyping = false // BEBAS
global.welcome = false // KALO MAU AUTO WELCOME UBAH JADI true
global.left = false // KALO MAU AUTO LEFT UBAH JADI true
global.anticall = true // BEBAS
global.autoread = false // BEBAS
global.packname = '© Store Bot' //sticker wm ubah
global.author = 'Store Bot' //sticker wm ganti nama kalian

/*
SUBS TOD
YT GUA
JER OFC 
*/

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})